import 'package:flutter/material.dart';

class HomeMenuBarListModel {
  final IconData? icon1;
  final String text;
  final IconData? icon2;

  HomeMenuBarListModel({this.icon1, required this.text, this.icon2});
}
