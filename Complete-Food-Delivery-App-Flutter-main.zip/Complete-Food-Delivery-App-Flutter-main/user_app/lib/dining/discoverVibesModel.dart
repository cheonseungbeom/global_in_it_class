class DiscoverVibeModel {
  final String imageLink;
  final String text;

  DiscoverVibeModel({required this.imageLink, required this.text});
}
