class MustTriesModel {
  final String imageLink;
  final String text;

  MustTriesModel({required this.imageLink, required this.text});
}
