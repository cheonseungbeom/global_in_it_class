class LookingForModel {
  final String name;
  final String imageLink;

  LookingForModel({required this.name, required this.imageLink});
}
