package com.example.admin_web_portal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
