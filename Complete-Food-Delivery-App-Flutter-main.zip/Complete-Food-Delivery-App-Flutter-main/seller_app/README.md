# seller_app

![Screenshot 2023-04-06 at 10 47 09 AM](https://user-images.githubusercontent.com/126752734/230278351-04dea81e-84d1-4505-bf40-1290b19752c9.png)
Good evening,
ma'am
Please find my today task . 
1. Implement Sellers Drawer.
2. Design Menus Upload Screen.
3. Capture menu image with Camera - Pick menu image from gallery.
4. Implement Upload Menus Form Screen Design.
5. Upload Menu Image and Get Image url as return.
6. Save menu info to Firestore Database .
7. Retrieve and Display Menus on Sellers Home Screen.
